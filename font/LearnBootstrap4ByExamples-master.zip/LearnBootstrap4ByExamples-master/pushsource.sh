git add . && git commit -am "update" && git push origin master
